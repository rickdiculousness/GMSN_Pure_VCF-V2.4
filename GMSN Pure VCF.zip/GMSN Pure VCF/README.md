Mouser BoM: http://www.mouser.com/ProjectManager/ProjectDetail.aspx?AccessID=eab9687744
